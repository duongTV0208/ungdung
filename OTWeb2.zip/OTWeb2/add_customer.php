<?php
require_once "dbconnect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $status = trim($_POST['status'] ?? '');

    if ($full_name == '' || $email == '' || $phone == '' || $status == '') {
        echo "<script>alert('Vui lòng nhập đầy đủ thông tin khách hàng'); window.history.back();</script>";
        exit();
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Email không hợp lệ'); window.history.back();</script>";
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO customers (full_name, email, phone, status) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        die("Lỗi chuẩn bị câu lệnh: " . $conn->error);
    }
    $stmt->bind_param("ssss", $full_name, $email, $phone, $status);
    if ($stmt->execute()) {
        echo "<script>alert('Thêm khách hàng thành công'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Thêm khách hàng thất bại'); window.history.back();</script>";
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm khách hàng mới</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Thêm khách hàng mới</h2>
    <form method="post" action="add_customer.php">
        <label>Họ và tên:</label><br>
        <input type="text" name="full_name" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Điện thoại:</label><br>
        <input type="text" name="phone" required><br><br>

        <label>Trạng thái:</label><br>
        <select name="status" required>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
            <option value="Pending">Pending</option>
        </select><br><br>

        <button type="submit">Thêm khách hàng</button>
    </form>
    <br>
    <a href="index.php">Quay lại trang chính</a>
</body>
</html>

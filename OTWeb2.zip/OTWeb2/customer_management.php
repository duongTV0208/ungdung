<?php
require_once "dbconnect.php";

// Hàm thêm khách hàng
function addCustomer($conn, $full_name, $email, $phone, $status) {
    $sql = "INSERT INTO customers (full_name, email, phone, status) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "Lỗi chuẩn bị câu lệnh: " . $conn->error;
        return false;
    }
    $stmt->bind_param("ssss", $full_name, $email, $phone, $status);
    $res = $stmt->execute();
    $stmt->close();
    return $res;
}

// Hàm lấy danh sách khách hàng theo trạng thái
function getCustomersByStatus($conn, $status) {
    $sql = "SELECT customer_id, full_name, email, phone, status FROM customers WHERE status = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "Lỗi chuẩn bị câu lệnh: " . $conn->error;
        return [];
    }
    $stmt->bind_param("s", $status);
    $stmt->execute();
    $result = $stmt->get_result();
    $customers = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $customers;
}

// Hàm cập nhật số điện thoại của khách hàng theo trạng thái
function updatePhoneByStatus($conn, $status, $newPhone) {
    $sql = "UPDATE customers SET phone = ? WHERE status = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "Lỗi chuẩn bị câu lệnh: " . $conn->error;
        return false;
    }
    $stmt->bind_param("ss", $newPhone, $status);
    $res = $stmt->execute();
    $stmt->close();
    return $res;
}

// Hàm xóa khách hàng theo tên miền email
function deleteCustomersByEmailDomain($conn, $domain) {
    $likePattern = "%" . $domain;
    $sql = "DELETE FROM customers WHERE email LIKE ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "Lỗi chuẩn bị câu lệnh: " . $conn->error;
        return false;
    }
    $stmt->bind_param("s", $likePattern);
    $res = $stmt->execute();
    $stmt->close();
    return $res;
}

// Xử lý POST form thêm khách hàng
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action == 'add') {
        $full_name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $status = trim($_POST['status'] ?? '');

        if ($full_name == '' || $email == '' || $phone == '' || $status == '') {
            echo "<script>alert('Vui lòng nhập đầy đủ thông tin khách hàng');</script>";
        } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "<script>alert('Email không hợp lệ');</script>";
        } else {
            if (addCustomer($conn, $full_name, $email, $phone, $status)) {
                echo "<script>alert('Thêm khách hàng thành công');</script>";
            } else {
                echo "<script>alert('Thêm khách hàng thất bại');</script>";
            }
        }
    } elseif ($action == 'update_phone') {
        $status = $_POST['status_update'] ?? '';
        $newPhone = $_POST['new_phone'] ?? '';

        if ($status == '' || $newPhone == '') {
            echo "<script>alert('Vui lòng nhập trạng thái và số điện thoại mới');</script>";
        } else {
            if (updatePhoneByStatus($conn, $status, $newPhone)) {
                echo "<script>alert('Cập nhật số điện thoại thành công');</script>";
            } else {
                echo "<script>alert('Cập nhật số điện thoại thất bại');</script>";
            }
        }
    } elseif ($action == 'delete_email') {
        $domain = trim($_POST['email_domain'] ?? '');
        if ($domain == '') {
            echo "<script>alert('Vui lòng nhập tên miền email');</script>";
        } else {
            if (deleteCustomersByEmailDomain($conn, $domain)) {
                echo "<script>alert('Xóa khách hàng thành công');</script>";
            } else {
                echo "<script>alert('Xóa khách hàng thất bại');</script>";
            }
        }
    }
}

// Lấy danh sách khách hàng theo trạng thái lọc (mặc định Active)
$filter_status = $_GET['status'] ?? 'Active';
$customers = getCustomersByStatus($conn, $filter_status);

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý khách hàng</title>
    <style>
        table { border-collapse: collapse; width: 100%; margin-top: 10px;}
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left;}
        th { background-color: #eee;}
        form { margin-top: 20px; margin-bottom: 20px; }
        label { display: inline-block; width: 120px; margin-bottom: 5px;}
        input, select { width: 200px; padding: 5px;}
        button { padding: 7px 15px; margin-top: 10px;}
    </style>
</head>
<body>

<h2>Danh sách khách hàng (Trạng thái: <?= htmlspecialchars($filter_status) ?>)</h2>

<form method="get">
    <label for="status">Lọc theo trạng thái:</label>
    <select name="status" id="status" onchange="this.form.submit()">
        <option value="Active" <?= $filter_status == 'Active' ? 'selected' : '' ?>>Active</option>
        <option value="Inactive" <?= $filter_status == 'Inactive' ? 'selected' : '' ?>>Inactive</option>
        <option value="Pending" <?= $filter_status == 'Pending' ? 'selected' : '' ?>>Pending</option>
    </select>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th><th>Họ tên</th><th>Email</th><th>Điện thoại</th><th>Trạng thái</th>
        </tr>
    </thead>
    <tbody>
    <?php if (count($customers) == 0): ?>
        <tr><td colspan="5" style="text-align:center;">Không có khách hàng nào</td></tr>
    <?php else: ?>
        <?php foreach ($customers as $c): ?>
            <tr>
                <td><?= htmlspecialchars($c['customer_id']) ?></td>
                <td><?= htmlspecialchars($c['full_name']) ?></td>
                <td><?= htmlspecialchars($c['email']) ?></td>
                <td><?= htmlspecialchars($c['phone']) ?></td>
                <td><?= htmlspecialchars($c['status']) ?></td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>

<hr>

<h3>Thêm khách hàng mới</h3>
<form method="post">
    <input type="hidden" name="action" value="add">
    <label>Họ và tên:</label>
    <input type="text" name="full_name" required><br>
    <label>Email:</label>
    <input type="email" name="email" required><br>
    <label>Điện thoại:</label>
    <input type="text" name="phone" required><br>
    <label>Trạng thái:</label>
    <select name="status" required>
        <option value="Active">Active</option>
        <option value="Inactive">Inactive</option>
        <option value="Pending">Pending</option>
    </select><br>
    <button type="submit">Thêm khách hàng</button>
</form>

<hr>

<h3>Cập nhật số điện thoại theo trạng thái</h3>
<form method="post">
    <input type="hidden" name="action" value="update_phone">
    <label>Trạng thái:</label>
    <select name="status_update" required>
        <option value="Active">Active</option>
        <option value="Inactive">Inactive</option>
        <option value="Pending">Pending</option>
    </select><br>
    <label>Số điện thoại mới:</label>
    <input type="text" name="new_phone" required><br>
    <button type="submit">Cập nhật số điện thoại</button>
</form>

<hr>

<h3>Xóa khách hàng theo tên miền email</h3>
<form method="post">
    <input type="hidden" name="action" value="delete_email">
    <label>Tên miền email (ví dụ: @example.com):</label>
    <input type="text" name="email_domain" required><br>
    <button type="submit">Xóa khách hàng</button>
</form>

</body>
</html>

<?php
$conn->close();
?>

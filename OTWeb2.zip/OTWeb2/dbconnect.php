<?php
$conn = new mysqli("127.0.0.1", "root", "", "customer_management");
?>
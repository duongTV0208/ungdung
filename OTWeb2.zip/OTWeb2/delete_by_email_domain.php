<?php
require_once "dbconnect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $domain = trim($_POST['email_domain'] ?? '');
    if ($domain == '') {
        echo "<script>alert('Vui lòng nhập tên miền email'); window.history.back();</script>";
        exit();
    }

    $likePattern = "%" . $domain;
    $stmt = $conn->prepare("DELETE FROM customers WHERE email LIKE ?");
    if (!$stmt) {
        die("Lỗi chuẩn bị câu lệnh: " . $conn->error);
    }
    $stmt->bind_param("s", $likePattern);

    if ($stmt->execute()) {
        echo "<script>alert('Xóa khách hàng thành công'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Xóa khách hàng thất bại'); window.history.back();</script>";
    }
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Xóa khách hàng theo tên miền email</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Xóa khách hàng theo tên miền email</h2>
    <form method="post" action="delete_by_email_domain.php">
        <label>Tên miền email (ví dụ: @example.com):</label><br>
        <input type="text" name="email_domain" required><br><br>

        <button type="submit">Xóa khách hàng</button>
    </form>
    <br>
    <a href="index.php">Quay lại trang chính</a>
</body>
</html>

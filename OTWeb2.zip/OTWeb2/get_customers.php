<?php
require_once "dbconnect.php";

function getCustomersByStatus($conn, $status) {
    $sql = "SELECT customer_id, full_name, email, phone, status FROM customers WHERE status = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Lỗi chuẩn bị câu lệnh: " . $conn->error);
    }
    $stmt->bind_param("s", $status);
    $stmt->execute();
    $result = $stmt->get_result();
    $customers = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $customers;
}
?>

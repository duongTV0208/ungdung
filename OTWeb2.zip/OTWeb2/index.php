<?php
require_once "dbconnect.php";
require_once "get_customers.php";

$filter_status = $_GET['status'] ?? 'Active';
$customers = getCustomersByStatus($conn, $filter_status);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý khách hàng</title>
    <style>
        table { border-collapse: collapse; width: 100%; margin-top: 10px;}
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left;}
        th { background-color: #eee;}
        .button-group {
            margin-top: 20px;
        }
        button {
            padding: 10px 20px;
            margin-right: 15px;
            font-size: 16px;
            cursor: pointer;
        }
        form { margin-top: 10px;}
    </style>
</head>
<body>

<h2>Danh sách khách hàng (Trạng thái: <?= htmlspecialchars($filter_status) ?>)</h2>

<form method="get">
    <label for="status">Lọc theo trạng thái:</label>
    <select name="status" id="status" onchange="this.form.submit()">
        <option value="Active" <?= $filter_status == 'Active' ? 'selected' : '' ?>>Active</option>
        <option value="Inactive" <?= $filter_status == 'Inactive' ? 'selected' : '' ?>>Inactive</option>
        <option value="Pending" <?= $filter_status == 'Pending' ? 'selected' : '' ?>>Pending</option>
    </select>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th><th>Họ tên</th><th>Email</th><th>Điện thoại</th><th>Trạng thái</th>
        </tr>
    </thead>
    <tbody>
    <?php if (count($customers) == 0): ?>
        <tr><td colspan="5" style="text-align:center;">Không có khách hàng nào</td></tr>
    <?php else: ?>
        <?php foreach ($customers as $c): ?>
            <tr>
                <td><?= htmlspecialchars($c['customer_id']) ?></td>
                <td><?= htmlspecialchars($c['full_name']) ?></td>
                <td><?= htmlspecialchars($c['email']) ?></td>
                <td><?= htmlspecialchars($c['phone']) ?></td>
                <td><?= htmlspecialchars($c['status']) ?></td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>

<div class="button-group">
    <form action="add_customer.php" method="get" style="display:inline;">
        <button type="submit">Thêm khách hàng mới</button>
    </form>
    <form action="update_phone.php" method="get" style="display:inline;">
        <button type="submit">Cập nhật số điện thoại theo trạng thái</button>
    </form>
    <form action="delete_by_email_domain.php" method="get" style="display:inline;">
        <button type="submit">Xóa khách hàng theo tên miền email</button>
    </form>
</div>

</body>
</html>

<?php $conn->close(); ?>

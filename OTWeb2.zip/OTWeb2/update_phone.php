<?php
require_once "dbconnect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $status = $_POST['status_update'] ?? '';
    $newPhone = $_POST['new_phone'] ?? '';

    if ($status == '' || $newPhone == '') {
        echo "<script>alert('Vui lòng nhập trạng thái và số điện thoại mới'); window.history.back();</script>";
        exit();
    }

    $stmt = $conn->prepare("UPDATE customers SET phone = ? WHERE status = ?");
    if (!$stmt) {
        die("Lỗi chuẩn bị câu lệnh: " . $conn->error);
    }
    $stmt->bind_param("ss", $newPhone, $status);

    if ($stmt->execute()) {
        echo "<script>alert('Cập nhật số điện thoại thành công'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Cập nhật số điện thoại thất bại'); window.history.back();</script>";
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Cập nhật số điện thoại theo trạng thái</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Cập nhật số điện thoại theo trạng thái</h2>
    <form method="post" action="update_phone.php">
        <label>Trạng thái:</label><br>
        <select name="status_update" required>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
            <option value="Pending">Pending</option>
        </select><br><br>

        <label>Số điện thoại mới:</label><br>
        <input type="text" name="new_phone" required><br><br>

        <button type="submit">Cập nhật số điện thoại</button>
    </form>
    <br>
    <a href="index.php">Quay lại trang chính</a>
</body>
</html>

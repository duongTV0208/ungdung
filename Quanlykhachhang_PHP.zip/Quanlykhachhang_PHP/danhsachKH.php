<?php
include 'ketnoi.php'; // Kết nối CSDL

// Gán trực tiếp trạng thái cần lọc
$status = " Không hoạt động";

// Truy vấn 
$stmt = $connect->prepare("SELECT id, fullname, email, phone, sttus FROM Khachhang WHERE sttus = ?");
$stmt->bind_param("s", $status);
$stmt->execute();

// Lấy kết quả
$result = $stmt->get_result();

// Hiển thị kết quả
if ($result->num_rows > 0) 
{
    while ($row = $result->fetch_assoc())
     {
        echo "ID: " . $row['id'] . "<br>";
        echo "Họ tên: " . $row['fullname'] . "<br>";
        echo "Email: " . $row['email'] . "<br>";
        echo "SĐT: " . $row['phone'] . "<br>";
        echo "Trạng thái: " . $row['sttus'] . "<br><hr>";
    }
} 
else
{
    echo "Không có khách hàng nào có trạng thái '$status'.";
}

// Đóng kết nối
$stmt->close();
$connect->close();
?>

<?php
//KHAI BÁO BIẾN
$servername ="localhost";
$username ="root";
$password = "";

// KẾT NỐI CSDL
$connect = new mysqli($servername,$username,$password);
//KIỂM TRA KẾT NỐI
if($connect ->connect_error)
{
    die("Kết nối thất bại".$connect->connect_error);
}
else
{
    echo ("Kết nối thành công<br>");
}
//TẠO CƠ SỞ DỮ LIỆU
$sql = "CREATE DATABASE IF NOT EXISTS QLKHACHHANG";
//KIỂM TRA TẠO CSDL
if($connect->query($sql)== TRUE)
{
    echo ("Tạo CSDL thành công");
}
else
{
    echo("Lỗi".$connect->error);
}
$connect->close();
?>

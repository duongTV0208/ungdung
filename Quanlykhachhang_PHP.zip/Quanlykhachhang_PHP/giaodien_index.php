<html>
<h1>Quản lý khách hàng</h1>
<ul>
    <li><a href="them.php">Thêm khách hàng</a></li>
    <li><a href="danhsachKH.php">Xem danh sách khách hàng (Active)</a></li>
    <li><a href="sua.php">Cập nhật số điện thoại cho khách hàng Inactive</a></li>
    <li><a href="xoa.php">Xoá khách hàng theo tên miền email</a></li>
</ul>
</html>


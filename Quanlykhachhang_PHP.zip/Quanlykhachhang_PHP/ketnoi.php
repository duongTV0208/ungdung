<?php
//KHAI BÁO BIẾN
$servername ="localhost";
$username ="root";
$password = "";
$csdl="QLKHACHHANG";

// KẾT NỐI CSDL
$connect = new mysqli($servername,$username,$password,$csdl);
//KIỂM TRA KẾT NỐI
if($connect ->connect_error)
{
    die("Kết nối CSDL thất bại".$connect->connect_error);
}
else
{
    echo ("Kết nối CSDL thành công<br>");
}
?>
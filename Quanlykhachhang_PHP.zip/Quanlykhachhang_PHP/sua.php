//Cập nhật số điện thoại của tất cả khách hàng trong một trạng thái cụ thể thành một số điện thoại mới.
<?php
include 'ketnoi.php'; // Kết nối CSDL
// Gán trực tiếp giá trị
$status = " Không hoạt động";  // Trạng thái cần cập nhật
$new_phone = "0123456789";    // Số điện thoại mới

// Cập nhật dữ liệu
$stmt = $connect->prepare("UPDATE Khachhang SET phone = ? WHERE sttus = ?");
$stmt->bind_param("ss", $new_phone, $status);

if ($stmt->execute())
{
    echo "Đã cập nhật số điện thoại cho tất cả khách hàng có trạng thái '$status'.";
} else
{
    echo "Lỗi: " . $stmt->error;
}

// Đóng kết nối
$stmt->close();
$connect->close();
?>


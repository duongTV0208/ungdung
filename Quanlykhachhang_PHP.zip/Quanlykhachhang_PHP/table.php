<?php
//KHAI BÁO BIẾN
$servername ="localhost";
$username ="root";
$password = "";
$csdl="QLKHACHHANG";

// KẾT NỐI CSDL
$connect = new mysqli($servername,$username,$password,$csdl);
//KIỂM TRA KẾT NỐI
if($connect ->connect_error)
{
    die("Kết nối thất bại".$connect->connect_error);
}
else
{
    echo ("Kết nối thành công<br>");
}
// TẠO BẢNG Khách hàng
$sql="CREATE TABLE IF NOT EXISTS Khachhang
(
id INT(5) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
fullname VARCHAR(30) NOT NULL,
email VARCHAR (20) NOT NULL,
phone VARCHAR(15) NOT NULL,
sttus VARCHAR(20) NOT NULL
)";
// KIỂM TRA KẾT NỐI BẢNG
if($connect->query($sql)==TRUE)
{
    echo ("Tạo bảng thành công");
}
else
{
    echo("Lỗi".$connect->error);
}
$connect->close();
?>
<?php
include 'ketnoi.php';//Gọi file kết nối CSDL
//if ($_SERVER["REQUEST_METHOD"] == "POST") 
//{
    //$id=$_POST['ID'];
    //$full_name = $_POST['Name:'];
    //$email = $_POST['Email:'];
    //$phone = $_POST['Phone:'];
    //$sttus = $_POST['Status:'];// chỉ sử dụng khi tạo form
      // Thêm khách hàng vào bảng khách hàng
    //$id=1; AUTO_INCREMENT nên bỏ qua thuộc tính is
    $full_name="Trần Hoa";
    $email="Hoa222@123.com";
    $phone="5566";
    $sttus="Hoạt động";

    // Dùng prepared statement để thêm dữ liệu an toàn
    $stmt = $connect->prepare("INSERT INTO Khachhang ( fullname, email, phone, sttus) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $full_name, $email, $phone, $sttus);
 
    if ($stmt->execute()) 
    {
        echo ("Đã thêm khách hàng thành công!");
    } 
    else 
    {
        echo ("Lỗi: " . $stmt->error);
    }
    $stmt->close();
    $connect->close();
?>
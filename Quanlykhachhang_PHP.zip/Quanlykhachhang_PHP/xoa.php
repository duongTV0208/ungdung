•	Xóa tất cả khách hàng có email thuộc một tên miền cụ thể (ví dụ: "@gmail.com").
<?php
include 'ketnoi.php';
// Gán tên miền email cần xóa
$x= "@gmail.com";

// Câu lệnh xóa trực tiếp
$sql = "DELETE FROM Khachhang WHERE email LIKE '%$x%'";

if ($connect->query($sql) === TRUE) 
{
    echo "Đã xóa tất cả khách hàng có email thuộc tên miền '$x'.";
} else 
{
    echo "Lỗi: " . $connect->error;
}

$connect->close();
?>
